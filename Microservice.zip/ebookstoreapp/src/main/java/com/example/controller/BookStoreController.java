package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.Domain.Book;
import com.example.service.IBookStroreService;

@RestController
@Scope(value="request")
public class BookStoreController {

	@Autowired
	@Qualifier(value="BookStoreService")
	private IBookStroreService BookStoreService;
	
	
	//adding a book
	@PostMapping(value="/books", produces= {MediaType.APPLICATION_JSON_VALUE},
			consumes= {MediaType.APPLICATION_JSON_VALUE})
	@ResponseStatus(code= HttpStatus.CREATED)
	
	public Book addBook(@RequestBody Book Book) {
		return BookStoreService.addBook(Book);
	}
	
	//updating a book
	@PutMapping(value="/books", produces= {MediaType.APPLICATION_JSON_VALUE},
			consumes= {MediaType.APPLICATION_JSON_VALUE})
	@ResponseStatus(code= HttpStatus.OK)
	
	public Book updateBook(@RequestBody Book Book) {
		return BookStoreService.updateBook(Book);
	}
	
	
	//deleting a book by id
	@DeleteMapping(value="/books/{id}")
	@ResponseStatus(code= HttpStatus.NO_CONTENT)
	public void updateBook(@PathVariable("id") Long Id) {
		BookStoreService.deleteBookById(Id);
	}
	
	//fetching all books
	@GetMapping(value="/books",produces= {MediaType.APPLICATION_JSON_VALUE})
	public List<Book> getAllBook() {
		return BookStoreService.getAllBook();
	}
	
	
	//fetching a book by id
	@GetMapping(value="/books/{id}",produces= {MediaType.APPLICATION_JSON_VALUE})
	public Book getProductById(@PathVariable("id") Long Id) {
		return BookStoreService.getBookById(Id);
	}
	
	//fetching a book by title
	@GetMapping(value="/books/title/{title}",produces= {MediaType.APPLICATION_JSON_VALUE})
	public List<Book> getBookByTitle(@PathVariable String title) {
		return BookStoreService.findByTitle(title);
	}
	
	//fetching a book by year
	@GetMapping(value="/books/year/{year}",produces= {MediaType.APPLICATION_JSON_VALUE})
	public List<Book> getBookByYear(@PathVariable int year) {
		return BookStoreService.findBybookYear(year);
	}
	
	
	//fetching a book by publisher like
		@GetMapping(value="/books/publisher/{publisher}",produces= {MediaType.APPLICATION_JSON_VALUE})
		public List<Book> getBookByPublisherLike(@PathVariable String publisher) {
			return BookStoreService.findByPublisherLike("%"+publisher+"%");
		}
}
