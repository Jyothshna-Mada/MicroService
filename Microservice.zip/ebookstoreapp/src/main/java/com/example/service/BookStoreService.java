package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.example.Domain.Book;
import com.example.repository.BookStoreRepository;

@Service(value="BookStoreService")
@Scope(value="singleton")
public class BookStoreService implements IBookStroreService{
	
	@Autowired
	@Qualifier(value="BookStoreRepository")
	private BookStoreRepository bookStoreRepository;

	@Override
	public Book addBook(Book Book) {
		return bookStoreRepository.save(Book);
	}

	@Override
	public Book updateBook(Book Book) {
		return bookStoreRepository.save(Book);
	}

	@Override
	public List<Book> getAllBook() {
		return bookStoreRepository.findAll();
	}

	@Override
	public Book getBookById(Long Id) {
		return bookStoreRepository.findById(Id).get();
	}

	@Override
	public void deleteBookById(Long Id) {
		bookStoreRepository.deleteById(Id);
		
	}

	@Override
	public List<Book> findByTitle(String title) {
		return bookStoreRepository.findByTitle(title);
	}

	@Override
	public List<Book> findByPublisherLike(String publisher) {
		
		return bookStoreRepository.findByPublisherLike(publisher);
	}

	@Override
	public List<Book> findBybookYear(int year) {
		
		return bookStoreRepository.findBybookYear(year);
	}

}
