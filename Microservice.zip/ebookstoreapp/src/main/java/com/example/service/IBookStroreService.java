package com.example.service;

import java.util.List;

import com.example.Domain.Book;

public interface IBookStroreService {
	
	public Book addBook(Book Book);
	public Book updateBook(Book Book);
	public List<Book> getAllBook();
	public Book getBookById(Long Id);
	public void deleteBookById(Long Id);
	
	List<Book> findByTitle(String title);
	List<Book> findByPublisherLike(String publisher);
	List<Book> findBybookYear(int year);

}
