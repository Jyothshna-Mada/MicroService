package com.example.eBookStore_cloud_gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EBookStoreCloudGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
