package com.example.employee_registration_consumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeRegistrationConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
