package com.example.consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Service;

import com.example.Domain.Employee;

@Service
public class EmployeeRegistrationConsumer {
	
	 private static final Logger logger = LoggerFactory.getLogger(EmployeeRegistrationConsumer.class);
	
	@RabbitListener(queues= {"${rabbitmq.queue.name}"})
	public void consume(Employee employee) {
		logger.info("Message Arrived! Message: "+employee);
	}
}
