package com.example.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.Domain.Book;
import com.example.service.BookService;

@RestController
@Scope("request")
public class BookClientController {

	
	@Autowired
	@Qualifier("BookService")
	private BookService bookService;
	
	private static final Logger log = LoggerFactory.getLogger(BookClientController.class);
	
	 @GetMapping("/books/{id}")
	    public Book getBookById(@PathVariable Long id) {
	        log.debug("In getBookById with Id: "+ id);
	        Book book = bookService.getBookById(id);
	        log.debug("In getBookById with return value book: "+ book);
	        return book;
	    }
}
