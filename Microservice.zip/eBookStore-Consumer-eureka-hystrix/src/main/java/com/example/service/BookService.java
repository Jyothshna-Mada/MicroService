package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.Domain.Book;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service(value= "BookService")
@Scope("singleton")
public class BookService {
	
	@Autowired
	private RestTemplate restTemplate;
	
		
	@HystrixCommand(fallbackMethod = "fallbackGetBookById")
	  public Book getBookById(Long id) {
	        Book book = restTemplate.getForObject("http://book-service/books/"+ id, Book.class);
	        return book;
	    }
	
	 public Book fallbackGetBookById(Long id) {
	        return new Book(id, "JavaProgramming","Dennies Ritche","978-09-86-3245", 1526, 2000, "Ranne mon");
	    }

}
